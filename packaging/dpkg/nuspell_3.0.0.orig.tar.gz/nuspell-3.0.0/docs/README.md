# Man-pages

- [Nuspell.1](nuspell.1.md)

Man-pages are auto generated from markdown (.md) by the tool
[Ronn](http://rtomayko.github.io/ronn/). If the tool is installed the build
system will run the tool on `make`.

On Ubuntu (up to 18.04) and Debian the tool can be simply installed by

    sudo apt install ruby-ronn

On Ubuntu 18.10 use

    sudo apt install ronn

On other platforms use ruby gems.
